import SwiftUI
import AVFoundation

struct ContentView: View {
    @StateObject private var audioManager = AudioEngineManager()
    @State private var projectName = ""
    @State private var savedProjects: [RemoteProject] = []
    @State private var showProjects = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    QuickLoopLogo()
                        .frame(width: 120, height: 120)
                        .padding(.top, 8)

                    recordPlayButtons

                    saveAndProjectsBar

                    TimelineAxis(duration: maxProjectDuration())
                        .padding(.horizontal)

                    ForEach($audioManager.tracks) { $track in
                        trackRow(track: $track)
                            .animation(
                                .spring(response: 0.5, dampingFraction: 0.7),
                                value: audioManager.tracks.count
                            )
                    }
                }
                .padding()
            }
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.black,
                        Color("Accent1").opacity(0.8)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
            )
            .navigationTitle("QuickLoop")
            .sheet(isPresented: $showProjects) {
                ProjectsView(
                    projects: $savedProjects,
                    open: { project in
                        audioManager.tracks = project.tracks
                        showProjects = false
                    }
                )
            }
            .task {
                await loadRemoteProjects()
            }
        }
    }

    private var recordPlayButtons: some View {
        HStack(spacing: 40) {
            NeonCircleButton(
                systemName: audioManager.isRecording ? "stop.fill" : "mic.fill",
                isActive: audioManager.isRecording,
                activeColor: .red
            ) {
                if audioManager.isRecording {
                    audioManager.stopRecording()
                } else {
                    audioManager.startRecording()
                }
            }

            NeonCircleButton(
                systemName: audioManager.isPlaying ? "stop.fill" : "play.fill",
                isActive: audioManager.isPlaying,
                activeColor: .green
            ) {
                if audioManager.isPlaying {
                    audioManager.stopAll()
                } else {
                    audioManager.playAll()
                }
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private var saveAndProjectsBar: some View {
        HStack(spacing: 12) {
            TextField("Project Name", text: $projectName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(8)
                .background(Color(.systemGray6).opacity(0.5))
                .cornerRadius(10)

            Button("Save") {
                Task {
                    audioManager.saveProject(named: projectName)

                    do {
                        let rp = try await ProjectService.shared.createProject(
                            name: projectName,
                            tracks: audioManager.tracks
                        )
                        savedProjects.append(rp)
                        projectName = ""
                    } catch {
                        print("Remote save error:", error)
                    }
                }
            }
            .buttonStyle(PrimaryButtonStyle())

            Button("Projects") {
                showProjects = true
            }
            .buttonStyle(PrimaryButtonStyle())
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }

    private func trackRow(track: Binding<Track>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            TextField("Track Name", text: track.name)
                .font(.headline)
                .foregroundColor(.white)
                .textFieldStyle(.plain)
                .padding(4)
                .background(Color(.systemGray5).opacity(0.2))
                .cornerRadius(6)

            TrackTimelineView(
                track: track,
                totalDuration: maxProjectDuration()
            )
            .frame(height: 100)
            .background(Color(.systemGray5).opacity(0.2))
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.3), radius: 4, x: 0, y: 2)

            HStack {
                Toggle("", isOn: track.isLooping)
                    .labelsHidden()
                    .toggleStyle(SwitchToggleStyle())

                Spacer()

                Button { audioManager.togglePlayPause(for: track.wrappedValue) } label: {
                    Image(systemName:
                        audioManager.players[track.wrappedValue.id]?.isPlaying == true
                        ? "stop.circle" : "play.circle"
                    )
                }
                .foregroundColor(.white)

                Button { audioManager.removeTrack(id: track.wrappedValue.id) } label: {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
                .buttonStyle(BorderlessButtonStyle())
            }
        }
        .padding()
        .background(Color("Accent2").opacity(0.2))
        .cornerRadius(16)
        .transition(.asymmetric(
            insertion: .move(edge: .bottom).combined(with: .opacity),
            removal: .scale.combined(with: .opacity)
        ))
    }


    private func loadRemoteProjects() async {
        do {
            savedProjects = try await ProjectService.shared.fetchProjects()
        } catch {
            print("Remote fetch failed, loading local:", error)
            let local = audioManager.loadProjects()
            savedProjects = local.map {
                RemoteProject(
                    id: $0.id.uuidString,
                    name: $0.name,
                    tracks: $0.tracks
                )
            }
        }
    }

    private func maxProjectDuration() -> Double {
        audioManager.tracks.map { $0.loopOut }.max() ?? 30
    }
}


struct NeonCircleButton: View {
    let systemName: String
    let isActive: Bool
    let activeColor: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 28, weight: .bold))
                .foregroundColor(isActive ? activeColor : .white)
                .frame(width: 60, height: 60)
                .background(
                    Circle()
                        .fill(Color.white.opacity(isActive ? 0.2 : 0.1))
                        .shadow(
                            color: activeColor.opacity(isActive ? 0.8 : 0.2),
                            radius: isActive ? 10 : 4
                        )
                )
        }
    }
}


struct QuickLoopLogo: View {
    @State private var spin = false

    var body: some View {
        ZStack {
            Circle()
                .trim(from: 0, to: 0.7)
                .stroke(
                    AngularGradient(
                        gradient: Gradient(colors: [.purple, .pink, .purple]),
                        center: .center
                    ),
                    style: StrokeStyle(lineWidth: 8, lineCap: .round)
                )
                .rotationEffect(.degrees(spin ? 360 : 0))
                .animation(.linear(duration: 4).repeatForever(autoreverses: false),
                           value: spin)

            Text("QL")
                .font(.system(size: 48, weight: .black, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        gradient: Gradient(colors: [.pink, .purple]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .shadow(radius: 4, x: 2, y: 2)
        }
        .onAppear { spin = true }
    }
}


struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(.vertical, 12)
            .padding(.horizontal, 24)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color("Accent1"), Color("Accent2")]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .foregroundColor(.black)
            .cornerRadius(10)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
            .shadow(
                color: .black.opacity(configuration.isPressed ? 0.2 : 0.4),
                radius: configuration.isPressed ? 2 : 6,
                x: 0, y: configuration.isPressed ? 1 : 4
            )
            .animation(.spring(response: 0.3, dampingFraction: 0.6),
                       value: configuration.isPressed)
    }
}

#Preview {
    ContentView()
}
