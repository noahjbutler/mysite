import SwiftUI

@main
struct QuickLoopApp: App {
    @StateObject private var audioManager = AudioEngineManager()
    @State private var showingBuilder = false

    var body: some Scene {
        WindowGroup {
            if showingBuilder {
                ContentView()
                    .environmentObject(audioManager)
            } else {
                WelcomeView {
                    showingBuilder = true
                }
            }
        }
    }
}
