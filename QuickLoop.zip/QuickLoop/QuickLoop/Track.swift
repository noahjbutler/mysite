import AVFoundation
import Combine
import SwiftUI

struct Track: Identifiable, Codable {
    let id: UUID
    let audioURL: URL

    var name: String

    var startOffset: Double = 0.0
    var isLooping: Bool = false
    var loopIn: Double = 0.0
    var loopOut: Double = 0.0

    init(url: URL) {
        id = UUID()
        audioURL = url
        name = url.lastPathComponent
    }

    enum CodingKeys: String, CodingKey {
        case id, audioURL, name, startOffset, isLooping, loopIn, loopOut
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        audioURL = try container.decode(URL.self, forKey: .audioURL)
        name = try container.decode(String.self, forKey: .name)
        startOffset = try container.decode(Double.self, forKey: .startOffset)
        isLooping = try container.decode(Bool.self, forKey: .isLooping)
        loopIn = try container.decode(Double.self, forKey: .loopIn)
        loopOut = try container.decode(Double.self, forKey: .loopOut)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(audioURL, forKey: .audioURL)
        try container.encode(name, forKey: .name)
        try container.encode(startOffset, forKey: .startOffset)
        try container.encode(isLooping, forKey: .isLooping)
        try container.encode(loopIn, forKey: .loopIn)
        try container.encode(loopOut, forKey: .loopOut)
    }
}
