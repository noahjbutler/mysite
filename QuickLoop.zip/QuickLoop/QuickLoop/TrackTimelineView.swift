import SwiftUI
import AVFoundation

struct TrackTimelineView: View {
    @Binding var track: Track
    let totalDuration: Double

    @State private var dragOffset = CGSize.zero
    private enum Handle { case left, right }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                WaveformRepresentable(url: track.audioURL)
                    .frame(height: 80)
                    .offset(x: xOffset(in: geo) + dragOffset.width)

                Rectangle()
                    .fill(Color.blue.opacity(0.6))
                    .frame(width: 4, height: 80)
                    .position(
                        x: handleX(time: track.loopIn, in: geo),
                        y: 40
                    )
                    .gesture(dragHandle(.left, in: geo))

                Rectangle()
                    .fill(Color.blue.opacity(0.6))
                    .frame(width: 4, height: 80)
                    .position(
                        x: handleX(time: track.loopOut, in: geo),
                        y: 40
                    )
                    .gesture(dragHandle(.right, in: geo))

                Color.clear
                    .contentShape(Rectangle())
                    .gesture(dragTrack(in: geo))
            }
        }
        .frame(height: 80)
    }


    private func xOffset(in geo: GeometryProxy) -> CGFloat {
        CGFloat(track.startOffset / totalDuration) * geo.size.width
    }

    private func handleX(time: Double, in geo: GeometryProxy) -> CGFloat {
        xOffset(in: geo)
        + (CGFloat(time / totalDuration) * geo.size.width)
        + dragOffset.width
    }


    private func dragTrack(in geo: GeometryProxy) -> some Gesture {
        DragGesture()
            .onChanged { value in
                dragOffset = value.translation
            }
            .onEnded { value in
                let deltaSec = Double(value.translation.width / geo.size.width) * totalDuration
                track.startOffset += deltaSec
                dragOffset = .zero
            }
    }

    private func dragHandle(_ handle: Handle, in geo: GeometryProxy) -> some Gesture {
        DragGesture()
            .onChanged { value in
                let deltaSec = Double(value.translation.width / geo.size.width) * totalDuration
                switch handle {
                case .left:
                    track.loopIn = max(0,
                                       min(track.loopIn + deltaSec,
                                           track.loopOut - 0.1))
                case .right:
                    Task {
                        let asset = AVURLAsset(url: track.audioURL)
                        let maxLen: Double
                        if #available(iOS 16.0, *) {
                            if let cmDuration = try? await asset.load(.duration) {
                                maxLen = CMTimeGetSeconds(cmDuration)
                            } else {
                                maxLen = 0
                            }
                        } else {
                            maxLen = CMTimeGetSeconds(asset.duration)
                        }
                        let newOut = min(maxLen,
                                         max(track.loopOut + deltaSec,
                                             track.loopIn + 0.1))
                        await MainActor.run { track.loopOut = newOut }
                    }
                }
            }
    }
}


struct WaveformRepresentable: View {
    let url: URL
    var body: some View {
        Rectangle()
            .fill(Color.gray.opacity(0.3))
            .overlay(Text(url.lastPathComponent).font(.caption2))
    }
}

struct TimelineAxis: View {
    let duration: Double
    var body: some View {
        HStack {
            Text("0s").font(.caption2)
            Spacer()
            Text("\(Int(duration))s").font(.caption2)
        }
        .padding(.horizontal)
    }
}
