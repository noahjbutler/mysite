

import Foundation

struct RemoteProject: Codable, Identifiable {
  let id: String
  var name: String
  var tracks: [Track]
}

enum ProjectServiceError: Error {
  case invalidURL
  case network(Error)
  case decoding
  case encoding
}

actor ProjectService {
  static let shared = ProjectService()
  private let base = URL(string: "http://localhost:4000")!

  func fetchProjects() async throws -> [RemoteProject] {
    let url = base.appendingPathComponent("projects")
    let (data, _) = try await URLSession.shared.data(from: url)
    guard let projects = try? JSONDecoder().decode([RemoteProject].self, from: data)
    else { throw ProjectServiceError.decoding }
    return projects
  }

  func createProject(name: String, tracks: [Track]) async throws -> RemoteProject {
    let url = base.appendingPathComponent("projects")
    var req = URLRequest(url: url)
    req.httpMethod = "POST"
    req.setValue("application/json", forHTTPHeaderField: "Content-Type")
    let body = RemoteProject(id: "", name: name, tracks: tracks)
    req.httpBody = try JSONEncoder().encode(body)
    let (data, _) = try await URLSession.shared.data(for: req)
    guard let created = try? JSONDecoder().decode(RemoteProject.self, from: data)
    else { throw ProjectServiceError.decoding }
    return created
  }

  func deleteProject(id: String) async throws {
    let url = base.appendingPathComponent("projects/\(id)")
    var req = URLRequest(url: url)
    req.httpMethod = "DELETE"
    _ = try await URLSession.shared.data(for: req)
  }
}
