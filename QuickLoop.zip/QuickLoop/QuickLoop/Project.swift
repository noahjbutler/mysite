import Foundation

struct Project: Identifiable, Codable {
    let id: UUID
    var name: String
    var tracks: [Track]

    init(name: String, tracks: [Track] = []) {
        id = UUID()
        self.name = name
        self.tracks = tracks
    }
}
