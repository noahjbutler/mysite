

import SwiftUI

struct WelcomeView: View {
  let onStart: () -> Void

  var body: some View {
    VStack {
      Spacer()

    
    QuickLoopLogo()
                        .frame(width: 150, height: 150)
                        .padding(.bottom, 24)

      Text("QuickLoop")
        .font(.largeTitle)
        .fontWeight(.bold)
        .foregroundStyle(
          LinearGradient(
            gradient: Gradient(colors: [.purple, .pink]),
            startPoint: .leading,
            endPoint: .trailing
          )
        )
        .padding(.top, 16)

      Text("Your portable multitrack looper.")
        .font(.title3)
        .foregroundColor(.secondary)
        .padding(.bottom, 40)

      Button(action: onStart) {
        Text("Start")
          .font(.title2)
      }
      .buttonStyle(PrimaryButtonStyle())

      Spacer()
    }
    .padding()
    .background(
      LinearGradient(
        gradient: Gradient(colors: [Color("Accent1").opacity(0.2), .white]),
        startPoint: .top,
        endPoint: .bottom
      )
      .ignoresSafeArea()
    )
  }
}
