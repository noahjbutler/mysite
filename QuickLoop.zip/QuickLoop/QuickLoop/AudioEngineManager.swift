
import Foundation
import AVFoundation
import Combine

class AudioEngineManager: ObservableObject {
    @Published var tracks: [Track] = []
    @Published var isRecording = false
    @Published var isPlaying   = false

    let engine = AVAudioEngine()
    private var recorder: AVAudioRecorder?
    var players: [UUID: AVAudioPlayerNode] = [:]

    init() {
        configureAudioSession()
        engine.connect(engine.mainMixerNode, to: engine.outputNode, format: nil)
        engine.prepare()
        try? engine.start()
    }

    private func configureAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
        try? session.overrideOutputAudioPort(.speaker)
        try? session.setActive(true)
    }


    func startRecording() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setCategory(.playAndRecord,
                                    mode: .default,
                                    options: [.defaultToSpeaker])
            try session.setActive(true)
        } catch {
            print(" Audio session setup error:", error)
        }

        let settings: [String: Any] = [
            AVFormatIDKey:            Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey:          44_100,
            AVNumberOfChannelsKey:    1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        let docs = FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)[0]
        let url = docs.appendingPathComponent(
            "track-\(Date().timeIntervalSince1970).m4a"
        )

        do {
            recorder = try AVAudioRecorder(url: url, settings: settings)
            recorder?.record()
            isRecording = true
        } catch {
            print(" Failed to start recording:", error)
        }
    }

    func stopRecording() {
        recorder?.stop()
        isRecording = false

        guard let url = recorder?.url else { return }
        let newTrack = Track(url: url)
        tracks.append(newTrack)
        attachPlayer(for: newTrack)
    }


    func playAll() {
        guard !tracks.isEmpty else { return }
        isPlaying = true
        configureAudioSession()
        if !engine.isRunning {
            try? engine.start()
        }

        for track in tracks {
            guard let node = players[track.id],
                  let file = try? AVAudioFile(forReading: track.audioURL)
            else { continue }

            let sr         = file.fileFormat.sampleRate
            let startFrame = AVAudioFramePosition(track.loopIn * sr)
            let count      = AVAudioFrameCount((track.loopOut - track.loopIn) * sr)

            node.scheduleSegment(
                file,
                startingFrame: startFrame,
                frameCount: count,
                at: nil,
                completionCallbackType: .dataConsumed
            ) { [weak self] _ in
                guard let self = self, self.isPlaying else { return }
                self.playAll()
            }
            node.play()
        }
    }

    func stopAll() {
        isPlaying = false
        players.values.forEach { $0.stop() }
    }


    func play(track: Track) {
        configureAudioSession()
        if !engine.isRunning {
            try? engine.start()
        }
        if players[track.id] == nil {
            attachPlayer(for: track)
        }
        guard let node = players[track.id],
              let file = try? AVAudioFile(forReading: track.audioURL)
        else { return }

        let sr         = file.fileFormat.sampleRate
        let startFrame = AVAudioFramePosition(track.loopIn * sr)
        let count      = AVAudioFrameCount((track.loopOut - track.loopIn) * sr)

        node.scheduleSegment(
            file,
            startingFrame: startFrame,
            frameCount: count,
            at: nil,
            completionCallbackType: .dataConsumed
        ) { [weak self] _ in
            guard let self = self,
                  let idx = self.tracks.firstIndex(where: { $0.id == track.id }),
                  self.tracks[idx].isLooping
            else { return }
            self.play(track: track)
        }
        node.play()
    }

    func stop(track: Track) {
        players[track.id]?.stop()
    }


    private func attachPlayer(for track: Track) {
        let node = AVAudioPlayerNode()
        engine.attach(node)
        engine.connect(node, to: engine.mainMixerNode, format: nil)
        players[track.id] = node

        if let file = try? AVAudioFile(forReading: track.audioURL),
           let idx  = tracks.firstIndex(where: { $0.id == track.id }) {
            tracks[idx].loopOut = Double(file.length) / file.fileFormat.sampleRate
        }
    }

    func removeTrack(id: UUID) {
        if let node = players[id] {
            node.stop()
            engine.detach(node)
            players.removeValue(forKey: id)
        }
        if let idx = tracks.firstIndex(where: { $0.id == id }) {
            tracks.remove(at: idx)
        }
    }

    func clearAllTracks() {
        stopAll()
        for node in players.values {
            engine.detach(node)
        }
        players.removeAll()
        tracks.removeAll()
    }


    private var projectsURL: URL {
        FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("QuickLoopProjects.json")
    }

    func saveProject(named name: String) {
        var all = loadProjects()
        all.append(Project(name: name, tracks: tracks))
        if let data = try? JSONEncoder().encode(all) {
            try? data.write(to: projectsURL)
        }
    }

    func loadProjects() -> [Project] {
        guard
            let data = try? Data(contentsOf: projectsURL),
            let decoded = try? JSONDecoder().decode([Project].self, from: data)
        else { return [] }
        return decoded
    }

    func removeSavedProjects(at offsets: IndexSet) {
        var all = loadProjects()
        all.remove(atOffsets: offsets)
        if let data = try? JSONEncoder().encode(all) {
            try? data.write(to: projectsURL)
        }
    }
    
    func toggleLoop(for track: Track, isOn: Bool) {
            if let idx = tracks.firstIndex(where: { $0.id == track.id }) {
                tracks[idx].isLooping = isOn
            }
        }

        func togglePlayPause(for track: Track) {
            if let playing = players[track.id]?.isPlaying, playing {
                stop(track: track)
            } else {
                play(track: track)
            }
        }
}
