
import SwiftUI

struct ProjectsView: View {
    @Binding var projects: [RemoteProject]
    let open: (RemoteProject) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            List {
                ForEach(projects) { project in
                    Button(project.name) {
                        open(project)
                    }
                }
                .onDelete(perform: delete)
            }
            .navigationTitle("Saved Projects")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear {
            }
        }
    }

    private func delete(at offsets: IndexSet) {
        projects.remove(atOffsets: offsets)
        AudioEngineManager().removeSavedProjects(at: offsets)
    }
}
