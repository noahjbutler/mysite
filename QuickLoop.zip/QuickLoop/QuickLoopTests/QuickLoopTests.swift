//
//  QuickLoopTests.swift
//  QuickLoopTests
//
//  Created by Noah Butler on 4/1/25.
//

import Testing
@testable import QuickLoop

struct QuickLoopTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
